#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <memory.h>
#include <math.h>
#include "snake.h"

// !!! Read ASSIGNMENT2.txt carefully before you start !!!
// This is where you work, fill up the TODO notations

static void snake_shift(snake_t *snake);
static void check_eat_apple(snake_t *snake, apple_t *apple);
static void apple_new(int n_rows, int n_cols, apple_t *apple);
static void insertSnakeBodyUnit(snake_t *snake);


// -------------------- world functions -----------------------------

void make_world(int n_rows, int n_cols, world_t world[][n_cols], snake_t *snake, apple_t *apple) {
    // cover the world with grass
    for (int i=0; i<n_rows; i++){
        for (int j=0; j<n_cols; j++) {
            world[i][j] = GRASS;
        }
    }

    // add apple
    world[apple->col][apple->row] = APPLE;

    // add snake
    world[snake->col[0]][snake->row[0]] = HEAD;
    for (int k=1; k<snake->length; k++){
        world[snake->col[k]][snake->row[k]] = SNAKE;
    }
}

void next_state(int n_rows, int n_cols, world_t world[][n_cols], snake_t *snake, apple_t *apple) {
    // update the position of the snake
    snake_shift(snake);

    // check eat apple and change apple->exist accordingly
    check_eat_apple(snake, apple);

    // Did snake just eat apple?
    bool apple_eaten = apple->exist == 0 ? true : false;

    if (apple_eaten){
        apple_new(n_rows, n_cols, apple);
    }

    // We can not "make world" if snake is outside of world
    if (!snake_hit_wall(NROWS, NCOLS, snake)) {
        make_world(n_rows, n_cols, world, snake, apple);
    }

    // If apple eaten snake shall grow
    // This must be done after make_world, otherwise the new segment will be shown at (0,0)
    if (apple_eaten) {
        insertSnakeBodyUnit(snake);
    }
}


// ------------------- Snake functions ------------------------------

// Creation of the snake with default parameters
// direction up, head at the center of the map and
// length = 2 (1 head + 1 body unit)
snake_t *snake_new(int n_rows, int n_cols) {
    // memory allocation - do not change
    snake_t *snake = malloc(sizeof(snake_t));
    if (snake == NULL) {
        perror("Couldn't create snake, giving up");
        exit(EXIT_FAILURE);
    }
    // Create the snake
    // TODO

    return snake;
}

// Called each time the snake east an apple
// The new body unit can be put anywhere on the map
// (eg at 0,0) and it's position will be corrected right
// at the next time iteration
void insertSnakeBodyUnit(snake_t *snake) {
    // TODO
}

// set the snake direction
void snake_turn(snake_t *snake, dir_t dir) {
    // TODO
}

// Update the position of the snake according
// to its direction.
void snake_shift(snake_t *snake) {
    // TODO
}

// Did the snake eat the apple
void check_eat_apple(snake_t *snake, apple_t *apple) {
    // TODO
}

// If the snake length is greater than 2,
// the snake can hit itself
bool snake_hit_self(snake_t *snake) {
    // TODO
}

// The snake must stay within the
// boundaries of the world.
bool snake_hit_wall(int n_rows, int n_cols, snake_t *snake) {
    // TODO
}

// ------------------- Apple functions ------------------------------

apple_t *apple_make(int n_rows, int n_cols){
    apple_t *apple = malloc(sizeof(apple_t));
    if (apple == NULL) {
        perror("Couldn't create apple, giving up");
        exit(EXIT_FAILURE);
    }
    int acol, arow;
    acol = rand() % n_cols;
    arow = rand() % n_rows;
    apple->col = acol;
    apple->row = arow;
    apple->exist = 1;

    return apple;
}

void apple_new(int n_rows, int n_cols, apple_t *apple){
    int acol = rand() % n_cols;
    int arow = rand() % n_rows;
    apple->col = acol;
    apple->row = arow;
    apple->exist = 1;
}