#include<stdlib.h>
#include<stdbool.h>
#include<stdio.h>
#include <memory.h>
#include <string.h>
/*
 * This is just for testing, to be able to test static functions,
 * normally NEVER include a .c file in another .c file
 */
#include "snake.c"


#define EQUALS(v1, v2) printf( (v1) == (v2) ? "Ok\n" : "Not ok\n")


// ----- The test methods ----------------------------
void test_snake_new(int n);
void test_insertSnakeBodyUnit(int n);
void test_snake_shift(int n);
void test_snake_turn(int n);
void test_snake_hit_self(int n);
void test_check_eat_apple(int n);

// ---------- Helper methods ----------
int main(void) {

    // Run one at the time until all works
    // Then possibly run all at once.
    // assume size of map = 50*50 (n = 50)
    int n = 50;

    // -- uncomment what you want to test --
    //test_snake_new(n);
    //test_insertSnakeBodyUnit(n);
    //test_snake_shift(n);
    //test_snake_turn(n);
    //test_snake_hit_self(n); // to pass, this needs snake_turn to be working too
    //test_check_eat_apple(n);

    exit(0);
}

// ------------ Test functions definitions -----------------


void test_snake_new(int n){
    printf("Test_snake_new\n");
    snake_t *snake;
    snake = snake_new(n, n);
    EQUALS(snake->dir, UP);
    EQUALS(snake->col[0]*1000000+snake->row[0]*10000+snake->row[1]*100+snake->col[1], 25252625);
    EQUALS(snake->length, 2);
}

void test_insertSnakeBodyUnit(int n){
    printf("Test_insertSnakeBodyUnit\n");
    snake_t *snake;
    snake = snake_new(n, n);
    insertSnakeBodyUnit(snake);
    if (snake->length != 3 || snake->col[2]>49 || snake->col[2]<0
        || snake->row[2]>49 || snake->row[2]<0 ){
        printf("Not ok\n");
    } else {
        printf("Ok\n");
    }

    insertSnakeBodyUnit(snake);
    EQUALS(snake->length, 4);
}

void test_snake_shift(int n){
    printf("Test_snake_shift\n");
    snake_t *snake;

    snake = snake_new(n, n);
    snake->dir = UP;
    snake_shift(snake);
    if (snake->col[0] != 25 || snake->col[1] != 25 || snake->row[0] != 24 || snake->row[1] != 25){
        printf("Not ok\n");
    } else {
        printf("Ok\n");
    }

    snake = snake_new(n, n);
    snake->dir = DOWN;
    snake_shift(snake);
    if (snake->col[0] != 25 || snake->col[1] != 25 || snake->row[0] != 26 || snake->row[1] != 25){
        printf("Not ok\n");
    } else {
        printf("Ok\n");
    }

    snake = snake_new(n, n);
    snake->dir = LEFT;
    snake_shift(snake);
    if (snake->col[0] != 24 || snake->col[1] != 25 || snake->row[0] != 25 || snake->row[1] != 25){
        printf("Not ok\n");
    } else {
        printf("Ok\n");
    }

    snake = snake_new(n, n);
    snake->dir = RIGHT;
    snake_shift(snake);
    if (snake->col[0] != 26 || snake->col[1] != 25 || snake->row[0] != 25 || snake->row[1] != 25){
        printf("Not ok\n");
    } else {
        printf("Ok\n");
    }
}

void test_snake_turn(int n){
    printf("Test_snake_turn\n");
    snake_t *snake;
    snake = snake_new(n, n);

    snake_turn(snake, LEFT);
    EQUALS(snake->dir, LEFT);

    snake_turn(snake, RIGHT);
    EQUALS(snake->dir, RIGHT);

    snake_turn(snake, UP);
    EQUALS(snake->dir, UP);

    snake_turn(snake, DOWN);
    EQUALS(snake->dir, DOWN);
}


void test_snake_hit_self(int n) {
    printf("Test_snake_hit_self\n");
    snake_t *snake;
    snake = snake_new(n, n);

    EQUALS(snake->length, 2);
    EQUALS(snake->dir, UP);
    snake_shift(snake);
    EQUALS(snake_hit_self(snake), false);

    snake_turn(snake, DOWN);    // Opposite direction
    snake_shift(snake);          // If length 2 never will collide!
    EQUALS(snake_hit_self(snake), false);

    insertSnakeBodyUnit(snake);
    EQUALS(snake->length, 3);   // If length > 2 possibly will collide!
    EQUALS(snake->dir, DOWN);
    snake_turn(snake, UP);    // Opposite direction
    snake_shift(snake);
    EQUALS(snake_hit_self(snake), true);
}


void test_check_eat_apple(int n){
    snake_t *snake;
    snake = snake_new(n, n);
    printf("Test_check_eat_apple\n");

    apple_t *apple = malloc(sizeof(apple_t));
    if (apple == NULL) {
        perror("Couldn't create apple, giving up");
        exit(EXIT_FAILURE);
    }

    apple->col = 14;
    apple->row = 12;
    apple->exist = 1;
    check_eat_apple(snake, apple);
    EQUALS(apple->exist, 1);

    apple->col = 25;
    apple->row = 25;
    apple->exist = 1;
    check_eat_apple(snake, apple);
    EQUALS(apple->exist, 0);
}

