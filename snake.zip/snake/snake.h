/*
 * Header file for snake with all necessary declarations
 * and structures. Follow them when you write the functions
 * in snake.c but you do not need to write anything more here.
 * (although you may edit NROWS/NCOLS/CELL_SIZE/UPDATE_SPEED
 * for your own purpose, default values 50/50/10/200, respectively)
 *
 */

// Size of the world
#define NROWS 50   // Logical size
#define NCOLS 50
// Appearance of each cell (a cell is one elementary unit of the world)
#define CELL_SIZE 10
// The higher the slower the snake moves
#define UPDATE_SPEED 200

typedef enum {                    // The type for cells
    GRASS, SNAKE, HEAD, APPLE     // The values in the type
} world_t;                        // Simpler name: enum is called world_t

// The direction of the snake head
// NOTE: The snake positions are given by their row and column indexes
// The origin cell (row index=0, column index=0) is on the upper left corner
// of the world, so:
//      - snake moves down  = row increases
//      - snake moves right = col increases
typedef enum {
    UP, RIGHT, DOWN, LEFT
} dir_t;

// The snake
typedef struct {
    int col[NROWS*NCOLS];
    int row[NROWS*NCOLS];
    int length;           // Length of snake. Used for points for player (default 2)
    dir_t dir;            // Direction of snake
} snake_t;

// The apple
typedef struct {
    int col;
    int row;
    int exist;        // 1 when apple is created and 0 as the snake eats it
} apple_t;

// -------- Functions declarations --------------

// We need a snake and an apple
snake_t *snake_new(int n_rows, int n_cols);
apple_t *apple_make(int n_rows, int n_cols);

// The world is created using the new snake and apple just created
void make_world(int n_rows, int n_cols, world_t world[][n_cols], snake_t *snake, apple_t *apple);

// Update the world
void next_state(int n_rows, int n_cols, world_t world[][n_cols], snake_t *snake, apple_t *apple);

// Status of the snake
void snake_turn(snake_t *snake, dir_t dir);
bool snake_hit_wall(int n_rows, int n_cols, snake_t *snake);
bool snake_hit_self(snake_t *snake);