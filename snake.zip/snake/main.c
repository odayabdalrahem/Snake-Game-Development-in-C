/*
 *     **** Nothing to do here ****
 *     (but you may experiment... at own risk)
 *
 *     The GUI and keyboard handling for the Snake game
 *     Using GTK3, see https://developer.gnome.org/gtk3/stable/
 *
 *     See CMakeList.txt for dependencies of libraries and more
 */
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "snake.h"   // Pasting the *.h file here (type and functions we use)

// Surface to draw the world
static cairo_surface_t *surface = NULL;

static void draw_message(cairo_t *cr, char *msg, int x, int y, bool center);

// Our (logical) world were everything happens
static world_t world[NROWS][NCOLS];

// Pointers to global data
static snake_t *snake;
static apple_t *apple;


//------ Initialization (called first of all) -------------

static void init() {
    // Initialize the snake
    snake = snake_new(NROWS, NCOLS);
    // Initialize the apple
    apple = apple_make(NROWS, NCOLS);
    // Initialize the world
    make_world(NROWS, NCOLS, world, snake, apple);
}

//------ The animation loop (called by a timer) -------------

static gboolean update(gpointer widget) {

    GtkWidget *drawing_area = widget;
    cairo_t *cr = cairo_create(surface);

    // Assign different colors to each feature in the world
    for (int row = 0; row < NROWS; row++) {
        for (int col = 0; col < NCOLS; col++) {
            if (world[row][col] == SNAKE) {
                cairo_set_source_rgb(cr, 0, 0, 1);  // Snake's body is blue
            } else if (world[row][col] == HEAD) {
                cairo_set_source_rgb(cr, 0, 1, 0);  // Snake's head is green
            } else if (world[row][col] == APPLE) {
                cairo_set_source_rgb(cr, 1, 0, 0);  // Apples are red
            } else {
                cairo_set_source_rgb(cr, 1, 1, 1);  // White background
            }
            cairo_rectangle(cr, row * CELL_SIZE, col * CELL_SIZE, CELL_SIZE, CELL_SIZE);
            cairo_fill(cr);
        }
    }

    // Draw points
    char pts_str[16];
    sprintf(pts_str, "Points: %d", snake->length - 2);
    draw_message(cr, pts_str, 5, 20, false);

    bool end_of_game = false;

    if (snake_hit_wall(NROWS, NCOLS, snake)) {
        fprintf(stderr, "Hit wall");   // Debug
        draw_message(cr, "Hit wall",
                     NROWS * CELL_SIZE / 2, NCOLS * CELL_SIZE / 2, true);
        end_of_game = true;
    }

    if (snake_hit_self(snake)) {
        fprintf(stderr, "Hit myself");   // Debug
        draw_message(cr, "Hit myself",
                     NROWS * CELL_SIZE / 2, NCOLS * CELL_SIZE / 2, true);
        end_of_game = true;
    }

    gtk_widget_queue_draw(drawing_area); // Must have!! Why?? Forcing redraw?
    cairo_destroy(cr);

    if (end_of_game) {
        return false;
    } else {
        next_state(NROWS, NCOLS, world, snake, apple); // Update the world!
        return true;
    }
}


// ------------ Handling keyboard -------------------

static gboolean key_press_event_cb(GtkWidget *widget,
                                   GdkEventKey *event,
                                   gpointer data) {
    if (event->keyval == GDK_KEY_Left) {
        snake_turn(snake, LEFT);
    } else if (event->keyval == GDK_KEY_Right) {
        snake_turn(snake, RIGHT);
    } else if (event->keyval == GDK_KEY_Up) {
        snake_turn(snake, UP);
    } else if (event->keyval == GDK_KEY_Down) {
        snake_turn(snake, DOWN);
    } else {
        // Nothing (space bar to start)
    }

    // We've handled the event, stop processing
    return false;
}

// ------------- How the text will be displayed on screen -----------

static void draw_message(cairo_t *cr, char *msg, int x, int y, bool center) {
    cairo_text_extents_t extents;
    cairo_select_font_face(cr, "Courier",
                           CAIRO_FONT_SLANT_NORMAL,
                           CAIRO_FONT_WEIGHT_BOLD);
    cairo_set_font_size(cr, 24);
    cairo_set_source_rgb(cr, 0, 0, 0);
    if (center) {
        cairo_text_extents(cr, msg, &extents);
        cairo_move_to(cr, x - extents.width / 2, y);
    } else {
        cairo_move_to(cr, x, y);
    }
    cairo_show_text(cr, msg);
}


// --------- Graphical stuff. Don't need to understand --------------

static const int window_max_x = CELL_SIZE * NROWS;    // Graphical size
static const int window_max_y = CELL_SIZE * NCOLS;

// Create a new surface of the appropriate size
static gboolean configure_event_cb(GtkWidget *widget,
                                   GdkEventConfigure *event,
                                   gpointer data) {
    if (surface) {
        cairo_surface_destroy(surface);
    }
    surface = gdk_window_create_similar_surface(gtk_widget_get_window(widget),
                                                CAIRO_CONTENT_COLOR,
                                                gtk_widget_get_allocated_width(widget),
                                                gtk_widget_get_allocated_height(widget));

    // We've handled the configure event, no need for further processing.
    return true;
}

/*
 * Redraw the screen from the surface. Note that the ::draw
 * signal receives a ready-to-be-used cairo_t that is already
 * clipped to only draw the exposed areas of the widget
 */
static gboolean draw_cb(GtkWidget *widget,
                        cairo_t *cr,
                        gpointer data) {
    cairo_set_source_surface(cr, surface, 0, 0);
    cairo_paint(cr);  // Must be there
    return false;
}

static void close_window(void) {
    if (surface != NULL)
        cairo_surface_destroy(surface);

}

static void activate(GtkApplication *app, gpointer user_data) {
    GtkWidget *window;
    GtkWidget *frame;
    GtkWidget *drawing_area;

    window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW (window), "SNAKE");

    g_signal_connect (window, "destroy", G_CALLBACK(close_window), NULL);

    gtk_container_set_border_width(GTK_CONTAINER (window), 8);

    frame = gtk_frame_new(NULL);
    gtk_frame_set_shadow_type(GTK_FRAME (frame), GTK_SHADOW_IN);
    gtk_container_add(GTK_CONTAINER (window), frame);

    drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(drawing_area, window_max_x, window_max_y);

    gtk_container_add(GTK_CONTAINER (frame), drawing_area);

    // Signals used to handle the backing surface
    g_signal_connect (drawing_area, "draw",
                      G_CALLBACK(draw_cb), NULL);
    g_signal_connect (drawing_area, "configure-event",
                      G_CALLBACK(configure_event_cb), NULL);
    g_signal_connect (window, "key-press-event",
                      G_CALLBACK(key_press_event_cb), NULL);
    gtk_widget_set_events(window, gtk_widget_get_events(window)
                                  | GDK_KEY_PRESS_MASK);

    gtk_widget_show_all(window);

    init();                           // Create the world
    g_timeout_add(UPDATE_SPEED, update, drawing_area); // Start timer to call the callback
}

int main(int argc, char **argv) {

    GtkApplication *app;
    int status;

    srand((unsigned) time(NULL));     // For rand()

    app = gtk_application_new("chl.hajo.snake", G_APPLICATION_FLAGS_NONE);
    g_signal_connect (app, "activate", G_CALLBACK(activate), NULL);
    status = g_application_run(G_APPLICATION (app), argc, argv);
    g_object_unref(app);

    return status;
}